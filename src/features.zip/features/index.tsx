import { Route, Routes } from "react-router";
import styled from "styled-components";
import Header from "../layout/header/Header";
import Sidebar from "../layout/sidebar/Sidebar";
import Task from "./Task/Task";

const Container = styled.div`
  width: 100%;
`;
const MainContent = styled.div`
  display: flex;
  width: 100%;
  
`;
const MainView = styled.div`

   background: pink;
  width: 80%;
  height: 100%;
  padding: 25px;
  background-color: rgba(233, 233, 233);
  overflow-y: scroll;
  &::-webkit-scrollbar {
    display: none;
  }
`;
const Home = () => {
  return (
    <Container>
      <Header />
      <MainContent>
        <Sidebar />
        <Routes>
          <Route path="task" element={<Task/>}/>
        </Routes>

      </MainContent>
    </Container>
  );
};

export default Home;
