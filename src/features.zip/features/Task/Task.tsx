import React from 'react';
import styled from 'styled-components';


const Container = styled.div`
  background: #fff;
`;

const Content = styled.div`
  padding: 25px;
`;

const TopBlock = styled.div`
  display: flex;
`;
const Task = () => {
  return(
   <></>
  )
};

export default Task;
