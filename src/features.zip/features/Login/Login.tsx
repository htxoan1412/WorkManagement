import React, { useEffect } from "react";
import styled from "styled-components";
import TextField from "@mui/material/TextField";
import { useForm } from "react-hook-form";
import { Box, Button, Checkbox, Modal, Typography } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../redux/reducer/store";
import { IAuthenticateReq } from "../../api/auth/types";
import { getAuthenticate } from "../../redux/actions/auth";
import { resetProgress } from "../../redux/reducer/auth/authReducer";
import { Navigate, useNavigate } from "react-router";
// import { style } from "@mui/system";
const label = { inputProps: { "aria-label": "Checkbox demo" } };
const FormLogin = styled.form`
  width: 320px;
  /* height: 500px; */
  color: palevioletred;
  display: flex;

  justify-content: center;
  flex-direction: column;
  align-items: center;
`;
const Title = styled.p`
  color: #000;
  font-size: 36px;
`;
const Input = styled(TextField)`
  bottom: 10px;

  width: 100%;
`;
const GroupCheckBox = styled.div`
  /* background-color: red; */
  display: flex;
  align-items: center;
  justify-content: center;
  padding-bottom: 20px;
`;
const GroupInput = styled.div`
  padding-bottom: 20px;
`;
const StyleCheckBox = styled.div`
  display: flex;
`;
const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  background: "white",
  borderRadius: "7.5px",
  p: 4,
};

const LoginForm = () => {
  // const { register, handleSubmit } = useForm<>();
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const progress = useSelector((state: RootState) => state.auth.progress);
  const accessToken = useSelector(
    (state: RootState) => state.auth.user.accessToken
  );
  const error = useSelector((state: RootState) => state.auth.error.message);
  const details = useSelector((state: RootState) => state.auth.error.details);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => setOpen(false);
  useEffect(() => {
    if (progress === "done" && accessToken) {
      navigate("home");
    } else {
      
    }
  }, [navigate,dispatch, progress, accessToken]);
  const onLogin = async (props: IAuthenticateReq) => {
    dispatch(
      getAuthenticate({
        userNameOrEmailAddress: props.userNameOrEmailAddress,
        password: props.password,
        rememberClient: false,
      })
    );
  };
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IAuthenticateReq>();
  return (
    <div style={{ padding: "0 20px", background: "#fff" }}>
      <FormLogin onSubmit={handleSubmit(onLogin)}>
        <Title>Login</Title>
        <GroupInput>
          <Input
            {...register("userNameOrEmailAddress")}
            label="User name or Email"
            variant="standard"
          />
          <Input
            {...register("password")}
            id="standard-error"
            label="Password"
            variant="standard"
            style={{ top: "10px" }}
          />
        </GroupInput>

        <StyleCheckBox>
          {" "}
          <Checkbox {...label} defaultChecked /> <p>Remember Me</p>
        </StyleCheckBox>
        <Button
          type="submit"
          variant="contained"
          style={{ background: "#0000000f1", marginBottom: "10px" }}
          onClick={handleOpen}
        >
          Login
        </Button>
{/* 
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          sx={{ zIndex: "999" }}
        >
          <Box sx={{ style}}>  
            {error}
            {details}
              <Button
                variant="outlined"
                sx={{ color: "black", background: "#7cd1f9" }}
                onClick={handleClose}
              >
                Ok
              </Button>
          
          </Box>
        </Modal> */}
      </FormLogin>
    </div>
  );
};

export default LoginForm;
